export class todolist
{
    date:number;
    day:string;
    viewing:string[];
}