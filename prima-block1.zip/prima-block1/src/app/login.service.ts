import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { auth } from 'firebase';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(public afAuth:AngularFireAuth) { }

  loginWithPassword(email: string, password: string) {
    console.log("Signing with email");
    console.log(email);
    console.log(password);
    this.afAuth.auth.createUserWithEmailAndPassword(email, password)
    .catch(function(error) {
      // Handle Errors here.
      var errorCode = error.code;
      var errorMessage = error.message;
      // ...
    });
    this.afAuth.auth.signInWithEmailAndPassword(email,password)
    .catch(function(error) {
      // Handle Errors here.
      var errorCode = error.code;
      var errorMessage = error.message;
      // ...
    }).then(function()
    {
        console.log("success");
    })
  
  }
  

  
  loginWithGoogle()
  {
    console.log("Redirecting....!!!!");
    this.afAuth.auth.signInWithRedirect(new auth.GoogleAuthProvider);
  }
  loginWithFacebook()
  {
     console.log("Redirecting to Facebook");
     this.afAuth.auth.signInWithRedirect(new auth.FacebookAuthProvider);
  }
  


  getLoggedInUser()
  {
    return this.afAuth.authState;
  }



  logOut()
  {
    this.afAuth.auth.signOut();
  }
}
