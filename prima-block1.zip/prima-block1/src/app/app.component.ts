import { Component, OnInit } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import {FormBuilder,Validators} from '@angular/forms';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireModule } from '@angular/fire';
import * as firebase from 'firebase';
import { LoginService } from './login.service';
import { AngularFireAuth } from '@angular/fire/auth';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  
  user:firebase.User;
  fname:"";
  lname="";
  email:string;
  password:string;
  constructor(public firestore:AngularFirestore,public loginService:LoginService,
    public afAuth:AngularFireAuth){
 
  }
  ngOnInit(): void {
    this.loginService.getLoggedInUser()
    .subscribe(user=>
     {
       console.log(user);
       this.user=user;
     })
  }
  loginWithGoogle()
  {
    console.log("logging... with Google");
    this.loginService.loginWithGoogle();
  }
  logout()
  {
    this.loginService.logOut();
  }
  loginWithFacebook()
  {
    console.log("logging...with Facebook");
    this.loginService.loginWithFacebook();
  }
  loginEmailPassword(form)
  {
    this.loginService.loginWithPassword(form.value.email,form.value.password);
  }
  mySlideImages = ['../assets/img/Sport-1.jpeg','../assets/img/Sport-2.jpeg','../assets/img/Sport-3.jpeg'];
  // myCarouselImages =['../assets/images/image1.jpg','../assets/images/image2.jpeg','../assets/images/image3.jpg'];
   
  mySlideOptions={items: 1, dots: true, nav: true};
  myCarouselOptions={items: 3, dots: true, nav: true};
  has=false;
}
