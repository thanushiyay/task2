export class users
{
    fname:string;
    lname:string;
    email:string;
    password:string;
}