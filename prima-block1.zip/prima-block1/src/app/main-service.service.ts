import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MainServiceService {

  public data:string;
  setOption(val)
  {
    debugger;
    this.data=val;
  }
  getOption()
  {
     return this.data;
  }
  constructor() { }
}
