import { Component, OnInit } from '@angular/core';
import { MainServiceService } from '../main-service.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  data:string;


constructor(public _mainService:MainServiceService) {
    debugger;
   
    }
  ngOnInit() {
    this.data=this._mainService.getOption();
  }
}
