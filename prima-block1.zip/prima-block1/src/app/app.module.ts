import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
 import { HomeComponent } from './home/home.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatSidenavModule} from '@angular/material';
import { AboutComponent } from './about/about.component';
import { MainServiceService } from './main-service.service';
import { ReactiveFormsModule } from '@angular/forms';
import { RecaptchaModule } from 'angular-google-recaptcha';
import {MatInputModule,MatButtonModule} from '@angular/material';
import {MatFormFieldModule} from '@angular/material/form-field';
//import 'youtube';
// import { YoutubePlayerModule } from 'ng2-youtube-player';
import {AngularFireModule} from '@angular/fire';
// import {AngularDireDatabaseModule} from '@angular/fire';
import {AngularFirestoreModule} from '@angular/fire/firestore';
import {environment} from 'src/environments/environment';
import {AngularFireAuthModule} from '@angular/fire/auth';
import { LoginService } from './login.service';
import { OwlModule } from 'ngx-owl-carousel';
import { InputUserDataComponent } from './input-user-data/input-user-data.component';
import { DisplayUserDataComponent } from './display-user-data/display-user-data.component';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
   HomeComponent,
   AboutComponent,
   InputUserDataComponent,
   DisplayUserDataComponent
  ],
  imports: [
    BrowserModule,
    MatInputModule,
    OwlModule,
    AngularFireAuthModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFirestoreModule,
    MatFormFieldModule,
    AppRoutingModule,
    MatButtonModule,
    HttpClientModule,
    ReactiveFormsModule,
    RecaptchaModule.forRoot({
      siteKey: '6LeAtLgUAAAAAN0stRMSk0Z-3fd5eTWh5WBziD1m',
  }),
    BrowserAnimationsModule,
    MatSidenavModule,
    FormsModule
  ],
  providers: [MainServiceService,LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { 
  // platformBrowserDynamic().bootstrapModule(AppModule);
}
