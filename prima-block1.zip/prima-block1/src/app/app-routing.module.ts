import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { AppComponent } from './app.component';
import { InputUserDataComponent } from './input-user-data/input-user-data.component';
import { DisplayUserDataComponent } from './display-user-data/display-user-data.component';


const routes: Routes = [
  {
    path:'home',  component:HomeComponent
  },
  {
    path:'about',component:AboutComponent
  },
  {
    path:'',component:InputUserDataComponent
  },
  {
    path:'user/:uid',component:DisplayUserDataComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
