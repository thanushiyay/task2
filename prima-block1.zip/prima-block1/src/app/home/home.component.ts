import { Component, OnInit, Input } from '@angular/core';
// import { listLazyRoutes } from '@angular/compiler/src/aot/lazy_routes';
import {todolist} from '../../todolist';
import { MainServiceService } from '../main-service.service';
// import { IgxCalendarComponent } from 'igniteui-angular';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements   OnInit{
    // @Input  selectedValue;
  public selectedValue:string;
  public svalue:string;
  date:number;
  day:string;
  selectedOption: string;
  printedOption: string;
  lists:todolist[]=
  [
    {date:1,day:'Monday',viewing:[
      "Notes for Meeting","Get new task","Get new task",
      "Buy something to test","Read an Article","Finished tasks"
    ]},
    {date:2,day:'Tuesday',viewing:[
      "Buy something to test","Read an Article",
      "Get new task","Get new task","Finished tasks","Notes for Meeting"
    ]}
  ];
  places=['Asia','America','Africa','Studies','Life','CodaGlobal','MyChintu'];
  constructor(public _mainService:MainServiceService)
  { 
        // this.svalue=this.selectedValue;
        
        // _mainService.setOption(this.printedOption);
        // this.svalue=_mainService.getOption();
  }
 ngOnInit(){
    //called after the constructor and called  after the first ngOnChanges() 
  }
  

  options = ['Asia','America','Chintu','Mantu','Pinkuuu','Bichukkkku'];
  print() {
    this.printedOption = this.selectedOption;
    this._mainService.setOption(this.printedOption);
    this.svalue=this._mainService.getOption();
  }
}