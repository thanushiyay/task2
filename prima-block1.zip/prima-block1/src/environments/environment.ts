// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig:{
    apiKey: "AIzaSyCEKD5D4c0cjOsxfzEFUqkkLtitOZNH6Ok",
    authDomain: "seevoov1.firebaseapp.com",
    databaseURL: "https://seevoov1.firebaseio.com",
    projectId: "seevoov1",
    storageBucket: "seevoov1.appspot.com",
    messagingSenderId: "140614511518",
    appId: "1:140614511518:web:59d60bea3b509d0f61048f"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
