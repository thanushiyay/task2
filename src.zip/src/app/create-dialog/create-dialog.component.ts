import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
import { TermsDialogComponent } from '../terms-dialog/terms-dialog.component';
import { FormControl,FormBuilder, Validators, FormGroup } from '@angular/forms';
import { DialogComponent } from '../dialog/dialog.component';
import { LoginService } from '../login.service';
// import {FormControl, Validators} from '@angular/forms';
@Component({
  selector: 'app-create-dialog',
  templateUrl: './create-dialog.component.html',
  styleUrls: ['./create-dialog.component.css']
})
export class CreateDialogComponent implements OnInit {

  myRecaptcha=new FormControl(false);
  constructor(public dialog:MatDialog,private fb:FormBuilder,private _loginService:LoginService) { }
  authError:any;
  myform:FormGroup;
  ngOnInit()
  {
      
     this.myform=this.fb.group(
       {
             firstName:['',[Validators.required,Validators.minLength(4)]],
             lastName:['',[Validators.required,Validators.minLength(4)]],
             email:['',[Validators.required,Validators.minLength(4),Validators.email]],
             password:['',[Validators.required,Validators.minLength(6),Validators.pattern('^[a-zA-Z0-9]+$')]],
             check:['',[Validators.required]],
             myRecaptcha:['',[Validators.required]]
       }
     );
     this._loginService.eventAuthError$.subscribe(data=>
      {
        this.authError=data;
      })
  }
  onSubmit(form: { value: any; }):void
  {
    this._loginService.createUser(form.value);
    //  console.log(this.myform.controls.firstName.touched);
     console.log(this.myform.get('firstName').value);
  }


      // Recaptcha
  onScriptLoad()
  {
    console.log("Google recaptch is ready for use");
  }
  onScriptError()
  {
     console.log("Something went wrong");
  }
  
  // goBack
  goBack()
  {
    this.dialog.closeAll();
    // this.dialog.open(DialogComponent);
  }

  OpenDialog()
  {
    this.dialog.open(TermsDialogComponent);
  }

}
