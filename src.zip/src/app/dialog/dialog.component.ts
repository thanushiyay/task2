import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
import { TermsDialogComponent } from '../terms-dialog/terms-dialog.component';
import { CreateDialogComponent } from '../create-dialog/create-dialog.component';
import { AngularFireAuth } from '@angular/fire/auth';
import { LoginService } from '../login.service';

@Component({ 
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {

  constructor(public dialog:MatDialog,private afAuth:AngularFireAuth,private _loginService:LoginService) { }

  ngOnInit() {
  }
  termsDialog()
  {
    this.dialog.open(TermsDialogComponent);
  }
  CreateDialog()
  {
    this.dialog.closeAll();
    this.dialog.open(CreateDialogComponent);
    
  }
  loginWithGoogle()
  {
       this._loginService.loginGoogle();
  }

}
