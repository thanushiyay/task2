import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MainServiceService {
 
  
  public data:string;
  public seeing_place:string;
  youtube_value: any;
  

  
  constructor() { }
  setOption(val)
  {
    // debugger;
    this.data=val;
  }
  getOption()
  {
    return this.data;
  }
  setSeeing_place(seeing_place)
  {
     this.seeing_place=seeing_place;
  }
  getSeeing_place()
  {
    return this.seeing_place;      
  }
  setYoutubeValue(youtube_value: any) {
    this.youtube_value=youtube_value;
  }
  getYoutubeValue() {
        return this.youtube_value;
  }

}

