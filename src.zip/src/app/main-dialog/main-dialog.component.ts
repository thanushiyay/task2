import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material';
import { MainServiceService } from '../main-service.service';
import { YoutubeDialogComponent } from '../youtube-dialog/youtube-dialog.component';
// import { TermsDialogComponent } from '../terms-dialog/terms-dialog.component';
@Component({
  selector: 'app-main-dialog',
  templateUrl: './main-dialog.component.html',
  styleUrls: ['./main-dialog.component.css']
})
export class MainDialogComponent implements OnInit {
  data:string;
  constructor(public dialog:MatDialog,private _mainService:MainServiceService) {
    debugger;
}

  ngOnInit() {
    this.data=this._mainService.getOption();
  }
  openYoutubeDialog(seeing_place:any)
  {
     this._mainService.setSeeing_place(seeing_place);
     this.dialog.closeAll();
     this.dialog.open(YoutubeDialogComponent);
  }
 

}
