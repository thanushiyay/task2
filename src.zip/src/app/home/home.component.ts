import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { DialogComponent } from '../dialog/dialog.component';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { MainDialogComponent } from '../main-dialog/main-dialog.component';
import { MainServiceService } from '../main-service.service';
import {AngularFireAuth}  from '@angular/fire/auth';
import { LoginService } from '../login.service';
// import {NgbDropdown} from '@ng-bootstrap/ng-bootstrap';
// import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [ NgbCarouselConfig ]
})
export class HomeComponent implements OnInit {


  user:firebase.User;
  constructor(config: NgbCarouselConfig,public dialog:MatDialog,
    public _mainService:MainServiceService,public afAuth:AngularFireAuth,
    public _loginService:LoginService) {
      config.interval = 2000;  
      config.wrap = true;  
      config.keyboard = false ;  
      config.pauseOnHover = true;   
  }

  


  
  printOption:string;
  selectedOption:string;
  selected:string;
  showHide=true;
  change_style_css:string;
  change_search_icon:string;
  opened=false;
  HideShow=false;
  HideClass:string;
  middle_hide=true;
  spinning_show=false;
  hideDrop:string;
  close=false;
  public slide_images = [

    '../../assets/images/home_page.jpg',
   
    '../../assets/images/home2.jpg',
   
    '../../assets/images/home3.jpg',
   
    '../../assets/images/home_page.jpg'
   
    ];
  // places:string[];
  places=[
    'Asia','Africa','Antartica','Kerala','Tamilnadu','Asia','Africa','Antartica','Kerala',
    'Tamilnadu','Asia','Africa','Antartica','Kerala','Tamilnadu'
  ];
 
  openDialog()
  {
  
    this.dialog.open(DialogComponent);
  }
  ngOnInit() {
    // this.selected=h;
    this.change_style_css='search_input';
    this.change_search_icon='search_input_i';
    this.afAuth.authState
    .subscribe(user=>
      {
        console.log(user);
        this.user=user;
      })
      this.hideDrop='dropdown-content';
  }
  change_style()
  {
    this.HideShow=true;
      this.showHide=false;
      this.change_style_css='toggle_style';
      this.change_search_icon='search_input_i2';
      this.HideClass='float_label';
  }
  closing_opened()
  {
       this.opened=false;
       this.HideShow=false;
       this.showHide=true;
       this.change_style_css="search_input";
       this.change_search_icon='search_input_i';
 
  }
  loading_module()
  {
    this.printOption=this.selectedOption;
    this._mainService.setOption(this.selectedOption);
    this.middle_hide=false;
    this.spinning_show=true;
    setTimeout(()=>
    {
      this.spinning_show=false;
       this.dialog.open(MainDialogComponent);
       this.middle_hide=true;
    },20);
    
   
  }

  showDropdown()
  {
    this.close=false;
     this.hideDrop='dropdown-content_block';
  }
  hideDropdown()
  {
    this.close=true;
    this.hideDrop='dropdown-content';
  }
  logout()
  {
    this._loginService.logout();
  }
}

  
