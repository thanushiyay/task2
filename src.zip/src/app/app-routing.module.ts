import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { CareersComponent } from './careers/careers.component';
import { TermsConditionsComponent } from './terms-conditions/terms-conditions.component';
import { ContactComponent } from './contact/contact.component';
import { AffiliatesComponent } from './affiliates/affiliates.component';


const routes: Routes = [
   {path:'', redirectTo:'home',pathMatch:'prefix'},
  {path:'home',component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'careers',component:CareersComponent},
  {path:'affiliates',component:AffiliatesComponent},
  {path:'terms',component:TermsConditionsComponent},
  {path:'contact',component:ContactComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
